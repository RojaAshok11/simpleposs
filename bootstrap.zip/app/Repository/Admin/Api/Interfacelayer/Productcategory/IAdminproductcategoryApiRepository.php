<?php

namespace App\Repository\Admin\Api\Interfacelayer\Productcategory;

interface IAdminproductcategoryApiRepository
{
    public function adminsearchproductcategory();
}
