<?php

namespace App\Repository\Admin\Api\Interfacelayer\Auth;

interface IAdminpasswordloginApiRepository
{
    public function adminpasswordlogin();

}
