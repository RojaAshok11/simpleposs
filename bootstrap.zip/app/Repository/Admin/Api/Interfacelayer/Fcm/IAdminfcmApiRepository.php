<?php

namespace App\Repository\Admin\Api\Interfacelayer\Fcm;

interface IAdminfcmApiRepository
{
    public function adminsavedeviceinfo();

}
