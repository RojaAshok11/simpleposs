<?php

namespace App\Repository\Admin\Api\Interfacelayer\Order;

interface IOrderhistoryApiRepository
{
    public function individualhistory();

    public function overallhistory();

}
