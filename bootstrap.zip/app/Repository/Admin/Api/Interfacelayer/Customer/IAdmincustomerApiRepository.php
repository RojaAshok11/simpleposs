<?php

namespace App\Repository\Admin\Api\Interfacelayer\Customer;

interface IAdmincustomerApiRepository
{
    public function adminsearchcustomer();
}
