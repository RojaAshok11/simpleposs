<div class="row <?php echo e($columnone); ?> p-1">
    <label class="fw-bolder <?php echo e($columntwo); ?>"><?php echo e($name); ?> </label>
    <label class="fst-normal text-break  <?php echo e($columnthree); ?>"><b> : </b> <?php echo $value; ?></label>
</div>
<?php /**PATH /Applications/MAMP/htdocs/simpleposv3/resources/views/helper/formhelper/showlabel.blade.php ENDPATH**/ ?>