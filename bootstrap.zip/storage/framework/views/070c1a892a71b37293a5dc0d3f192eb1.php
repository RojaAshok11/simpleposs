<div class="<?php echo e($col); ?> mx-auto mb-1">
    <nav class="nav nav-pills flex-column flex-sm-row shadow-sm rounded-pill bg-white">
        <a wire:navigate class="flex-sm-fill text-sm-center nav-link rounded-pill <?php echo e($name == 'state' ? 'active' : ''); ?>"
            aria-current="page" href="<?php echo e(route('state')); ?>">State</a>

        <a wire:navigate class="flex-sm-fill text-sm-center nav-link rounded-pill <?php echo e($name == 'city' ? 'active' : ''); ?>"
            href="<?php echo e(route('city')); ?>">City</a>
    </nav>
</div>
<?php /**PATH /Applications/MAMP/htdocs/simpleposv3/resources/views/admin/settings/locationsettings/partial.blade.php ENDPATH**/ ?>