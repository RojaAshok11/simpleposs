<h5><?php echo e(__('Purchase Reports')); ?></h5>
<div class="pb-4 pt-2">
    <div class="row g-3 row-cols-1 row-cols-md-2">

        <div class="col-md-2">
            <a wire:navigate href="<?php echo e(route('purchasereport')); ?>" class="text-decoration-none text-dark text-center">
                <div class="card shadow-sm bg-white">
                    <i class="bi bi-box2" style="font-size: 2.4rem;"></i>
                    <div class="card-footer">
                        <div class="fw-b"><?php echo e(__('Purchase Reports')); ?> </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-2">
            <a wire:navigate href="<?php echo e(route('purchaseitemreport')); ?>"
                class="text-decoration-none text-dark text-center">
                <div class="card shadow-sm bg-white">
                    <i class="bi bi-box2-fill" style="font-size: 2.4rem;"></i>
                    <div class="card-footer">
                        <div class="fw-b"><?php echo e(__('Purchaseitems Reports')); ?> </div>
                    </div>
                </div>
            </a>
        </div>


    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/simpleposv3/resources/views/admin/reports/reports/purchasereports.blade.php ENDPATH**/ ?>