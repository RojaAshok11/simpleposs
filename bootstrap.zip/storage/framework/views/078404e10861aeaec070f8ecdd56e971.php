<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
<link rel="stylesheet"
    href="<?php echo e(asset('css/' . (App::make('themesetting') ? App::make('themesetting')->path : 'theme/bluetheme.css'))); ?>">
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->startSection('headSection'); ?>
<?php echo $__env->yieldSection(); ?>
<?php /**PATH /Applications/MAMP/htdocs/starpos_feedback_web/resources/views/components/admin/layouts/adminheaderlibrary.blade.php ENDPATH**/ ?>